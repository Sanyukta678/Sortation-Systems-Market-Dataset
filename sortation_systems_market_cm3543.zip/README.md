# Sortation Systems Market Dataset (CM3543)

This dataset is a reconstructed summary based on publicly available information from the NextMSC report page.

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt
